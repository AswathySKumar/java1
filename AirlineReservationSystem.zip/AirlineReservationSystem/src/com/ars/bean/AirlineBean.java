 package com.ars.bean;

public class AirlineBean {
	//(flight_id number(6),flight_name varchar(10),seats number(30))
	private int flight_id;
	private String flight_name;
	private int seats;
	public AirlineBean() {
		
	}
	public int getFlight_id() {
		return flight_id;
	}
	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}
	public String getFlight_name() {
		return flight_name;
	}
	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public AirlineBean(int flight_id, String flight_name, int seats) {
		super();
		this.flight_id = flight_id;
		this.flight_name = flight_name;
		this.seats = seats;
	}
	@Override
	public String toString() {
		return "AirlineBean [flight_id=" + flight_id + ", flight_name=" + flight_name + ", seats=" + seats + "]";
	}
	
	
}
