package com.ars.bean;

public class AirlineBean2 {
//	flight_id number(6),passengername varchar(10),reqseats number(30)
	private int flight_id;
	private String passengername;
	private int reqseats;
	public AirlineBean2() {
		
	}
	public int getFlight_id() {
		return flight_id;
	}
	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}
	public String getPassengername() {
		return passengername;
	}
	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}
	public int getReqseats() {
		return reqseats;
	}
	public void setReqseats(int reqseats) {
		this.reqseats = reqseats;
	}
	public AirlineBean2(int flight_id, String passengername, int reqseats) {
		super();
		this.flight_id = flight_id;
		this.passengername = passengername;
		this.reqseats = reqseats;
	}
	@Override
	public String toString() {
		return "AirlineBean2 [flight_id=" + flight_id + ", passengername=" + passengername + ", reqseats=" + reqseats
				+ "]";
	}
	
	
}
