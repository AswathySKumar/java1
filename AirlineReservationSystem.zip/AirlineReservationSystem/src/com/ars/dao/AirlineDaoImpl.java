package com.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ars.bean.AirlineBean;
import com.ars.bean.AirlineBean2;
import com.ars.exception.AirlineException;
import com.ars.util.DbUtil;

public class AirlineDaoImpl implements IAirlineDao {

	Connection conn=null;
	@Override
	public int addPassengerInfo(AirlineBean2 air) throws AirlineException {
		int status=0;
		conn=DbUtil.getDbConnection();
	
		try {
		//	PreparedStatement ps=conn.prepareStatement(IQueryMapper.);
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Airline_INSERT_QRY);
			pst.setInt(1,air.getFlight_id());
			pst.setString(2,air.getPassengername());
			pst.setInt(3,air.getReqseats());
					
			status=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			//logg.error("data is not inserted");
			throw new AirlineException("data not stored "+e.getMessage());
			
		}
		
		return status;
		
	}
	@Override
	public AirlineBean retrieveallinfo(int id) throws AirlineException {
		//PropertyConfigurator.configure("resource/log4j.properties");
		//Logger logger= Logger.getRootLogger();
		conn=DbUtil.getDbConnection();
		AirlineBean empList=null;
		try {
			String s=IQueryMapper.SELECT_AIRLINE_QRY1;
			PreparedStatement pst=conn.prepareStatement(s);
			pst.setInt(1, id);
		//	Statement st=conn.createStatement();
			ResultSet rs=pst.executeQuery();
		
			//empList=new ArrayList();
			//AssetBean emp=null;
			if(rs.next()){
				
				empList=new AirlineBean(rs.getInt(1),rs.getString(2),rs.getInt(3));
				
			}
			
			
		} catch (SQLException e) {
			//catch it as predefined and throw it as user defined with message
			//raise excpetion
			//logger.error("couldn't retrieve data from db");
			throw new AirlineException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return empList;
	}
	@Override
	public boolean checkFlight(int id1) {
		try {
			conn=DbUtil.getDbConnection();
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.flight_check);
			prepare.setInt(1, id1);
			ResultSet rs=prepare.executeQuery();
			if(rs.next()) {
				return true;
			}
			return false;
		} catch (SQLException e) {
			System.out.println("please enter valid flight id");
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public int update(int id1) throws AirlineException{
		int status=0;
		conn=DbUtil.getDbConnection();
	
		try {
		//	PreparedStatement ps=conn.prepareStatement(IQueryMapper.);
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.flight_check1);
		/*	pst.setInt(1,air.getFlight_id());
			pst.setString(2,air.getPassengername());
			pst.setInt(3,air.getReqseats());*/
					
			status=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			//logg.error("data is not inserted");
			throw new AirlineException("data not stored "+e.getMessage());
			
		}
		
		return status;
		
	}

		
	}	


