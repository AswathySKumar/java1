package com.ars.dao;

public interface IQueryMapper {
	public static final String Airline_INSERT_QRY="insert into register values(?,?,?)";
	public static final String SELECT_AIRLINE_QRY1="SELECT * FROM airline where flight_id=?";
	public static String flight_check="SELECT flight_id from airline where flight_id=?";
	public static String flight_check1="select seats from airline where flight_id=?";
}
