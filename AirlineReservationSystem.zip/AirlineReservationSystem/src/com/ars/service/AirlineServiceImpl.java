package com.ars.service;

import com.ars.bean.AirlineBean;
import com.ars.bean.AirlineBean2;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService{
IAirlineDao dao=new AirlineDaoImpl();
	
	
	@Override
	public int addPassengerInfo(AirlineBean2 air) throws AirlineException {
int i=dao.addPassengerInfo(air);
		
		return i;
	}


	@Override
	public AirlineBean retrieveallinfo(int id) throws AirlineException {
		
		return dao.retrieveallinfo(id);
	}


	@Override
	public boolean checkFlight(int id1) {
		
		return dao.checkFlight(id1);
	}


	@Override
	public int update(int id1) throws AirlineException {
		return dao.update(id1);
		
	}

}
