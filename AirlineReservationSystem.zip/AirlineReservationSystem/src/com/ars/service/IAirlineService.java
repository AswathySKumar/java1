package com.ars.service;

import com.ars.bean.AirlineBean;
import com.ars.bean.AirlineBean2;
import com.ars.exception.AirlineException;

public interface IAirlineService {

	public abstract int addPassengerInfo(AirlineBean2 air) throws AirlineException;

	public abstract AirlineBean retrieveallinfo(int id) throws AirlineException;

	public abstract boolean checkFlight(int id1);

	public abstract int update(int id1) throws AirlineException;

}
