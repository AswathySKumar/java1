package com.ars.ui;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


import com.ars.bean.AirlineBean;
import com.ars.bean.AirlineBean2;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

public class AirlineClient {
	static IAirlineService serv=new AirlineServiceImpl();
	static Scanner scan=null;
	static Connection conn=null;
	int seats;
	public static void main(String[] args) throws SQLException, AirlineException {
		System.out.println("===Airline Reservation system===");
		System.out.println("--------------------------------");
		System.out.println("1. Reservation");
		System.out.println("2. retrieve by id");
		System.out.println("3.reservation");
		System.out.println("--------------------------------");
		scan=new Scanner(System.in);
		int option=scan.nextInt();
		switch(option){
		case 1:
			
			System.out.println("enter flight_id");
			int id=scan.nextInt();
			System.out.println("enter passenger name ");
			String name=scan.next();
			System.out.println("enter required seats");
			int seats=scan.nextInt();
			AirlineBean2 bea2=new AirlineBean2(id,name,seats);
			int res=0;
			try {
				res = addPassenger(bea2);
			} catch (AirlineException e) {
			
			System.out.println(e.getMessage());
				//logg.error(e.getMessage());
			}
			
			if(res>0){
				System.out.println(res+" data is inserted");
				//logg.info("data is inserted"+res);
			}
			else
			{
				System.out.println("data is not stored");
				//logg.error("data is not inserted");
			}
			break;
			
		
		case 2:
			AirlineBean finList1=null;
			AirlineBean2 dea=null;
			try {
			System.out.println("enter the flight id");
			 id=scan.nextInt();
			finList1=retrieveall(id);
			System.out.println(finList1.toString());
		
			
			}
			catch(AirlineException e) {
				System.out.println(e.getMessage());
				
			}
		case 3:
			System.out.println("enter flight_id");
			int id1=scan.nextInt();
			if(serv.checkFlight(id1)) {
				System.out.println("enter passenger name ");
				String name1=scan.next();
				System.out.println("enter required seats");
				int seats1=scan.nextInt();
				AirlineBean2 bb=new AirlineBean2(id1,name1,seats1);
				int rese=0;
				try {
					rese = addPassenger(bb);
				} catch (AirlineException e) {
				
				System.out.println(e.getMessage());
					//logg.error(e.getMessage());
				}
				
				if(rese>0){
					serv.update(id1);
					System.out.println(rese+" data is inserted");
					
					//logg.info("data is inserted"+res);
				}
				else
				{
					System.out.println("data is not stored");
					//logg.error("data is not inserted");
				}
				
					
				}
			}
	/*	case 4:
			try {
				int status;
				if(status>0) {
					serv.update()
				}
			}*/
			
	}
	public static int addPassenger(AirlineBean2 air) throws AirlineException{
		int a=serv.addPassengerInfo(air);
		return a;
		
	}
	public static AirlineBean retrieveall(int id) throws AirlineException{

		
		return serv.retrieveallinfo(id);
		
	}

}
