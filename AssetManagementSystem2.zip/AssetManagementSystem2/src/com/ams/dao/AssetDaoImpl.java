package com.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ams.dtobean.AssetAllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;
import com.ams.util.DbUtil;


public class AssetDaoImpl implements IAsserDao{
	Connection conn=null;
	String ab=null;
	AssetBean bean= null;
	@Override
	public AssetBean validateUserType(String un) throws AssetException {
		try {
			conn=DbUtil.getDbConnection();
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.SELECT_USERTYPE_QRY);
			pst.setString(1,un);
			
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				bean=new AssetBean(rs.getString(1), rs.getString(2)); 
				System.out.println(rs.getString(2));	
			}
		
		}
		catch(SQLException e)
		{
			throw new AssetException(e.getMessage());
		}
		return bean;
	
	}
	@Override
	public int insertAsset(AssetBean bean2)
	{
		conn=DbUtil.getDbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			pst.setString(1,bean2.getAssetName());
			pst.setString(2,bean2.getAssetDes());
			pst.setInt(3, bean2.getQuantity());
			pst.setString(4, bean2.getStatus());
			status=pst.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Some error occured"+e);
		}
		return status;
	}
	@Override
	public int updateAsset(int id,int quantities, String name) throws AssetException {
		int status=0;
		conn=DbUtil.getDbConnection();
	   
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.ASSET_UPDATE_NAME);
			pst.setString(1,name);
			pst.setInt(2, quantities);
			pst.setInt(3, id);
			status=pst.executeUpdate();
		
			System.out.println(status);
		  }
		catch (SQLException e) {
			throw new AssetException("couldn't retrieve data from db  "+e.getMessage());
		}
		return status;
	}
	@Override
	public int raiseRequest(AssetAllocationBean allocBean) throws AssetException {
		conn=DbUtil.getDbConnection();
		int status=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.ASSET_ALLOCATION_INSERT_QUERY);
			
			pst.setInt(1,allocBean.getAllocationId());
			pst.setInt(2,allocBean.getAssetId());
			pst.setInt(3, allocBean.getEmpNo());
			pst.setString(4,allocBean.getReleaseDate()); 
			status=pst.executeUpdate();
		} catch (SQLException e) {
			throw new AssetException(e.getMessage());
		}
		return status;
	}
	@Override
	public int validateAssetId(int assetId) throws AssetException {
		conn=DbUtil.getDbConnection();
		int aid=0;
		try {
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.VALIDATE_ASSET_ID);
		pst.setInt(1, assetId);
		ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				aid=rs.getInt(1);
			}
		}
		catch(SQLException e) {
			throw new AssetException(e.getMessage());
			
		}
		return aid;
	}
	@Override
	public int updateAssetStatus(int allocationId,String stat) {
		int result=0;
		conn=DbUtil.getDbConnection();
		try {
			PreparedStatement pstm=conn.prepareStatement(IQueryMapper.ALLOCATION_STATUS_UPDATE);
			pstm.setString(1,stat);
			pstm.setInt(2, allocationId);
			result=pstm.executeUpdate();
		} catch (SQLException e) {
			
			System.out.println("cannot retreive data from database"+e.getMessage());
		}
		return result;
	}
	@Override
	public List<AssetAllocationBean> retrieveAll() {
		conn=DbUtil.getDbConnection();
		List<AssetAllocationBean> assetList=null;
		try {
			PreparedStatement pt=conn.prepareStatement(IQueryMapper.SELECT_ASSET_ALLOCATION);
			ResultSet rs=pt.executeQuery();
			assetList=new ArrayList();
			AssetAllocationBean aBean=null;
			while(rs.next())
			{
				aBean=new AssetAllocationBean(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6));
				assetList.add(aBean);
			}
		} catch (SQLException e) {
			System.out.println("cannot retreive the data"+e.getMessage());
		}
		return assetList;
	}
}
