package com.ams.dao;

public interface IQueryMapper {
	public static final String SELECT_USERTYPE_QRY="SELECT username,userpassword FROM user_master WHERE username=?";
	public static final String INSERT_QUERY="INSERT INTO asset VALUES(asset_seq.NEXTVAL,?,?,?,?)";
	public static final String ASSET_UPDATE_NAME="UPDATE asset SET assetname=?,quantity=? WHERE assetId=?";
	public static final String ASSET_ALLOCATION_INSERT_QUERY="INSERT INTO Asset_Allocation VALUES(allocationid_seq.NEXTVAL,?,?,SYSDATE,?)";
    public static final String VALIDATE_ASSET_ID="SELECT AssetId FROM Asset WHERE AssetId =?";
    public static final String ALLOCATION_STATUS_UPDATE="UPDATE asset_allocation SET status=? WHERE allocationid=?";
    public static final String SELECT_ASSET_ALLOCATION="SELECT * FROM ASSET_ALLOCATION";

}
