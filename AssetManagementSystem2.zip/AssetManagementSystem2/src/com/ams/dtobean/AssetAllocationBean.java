package com.ams.dtobean;

public class AssetAllocationBean {
	
	private int allocationId;
	private int assetId;
	private int empNo;
	private String allocationDAte;
	private String releaseDate;
	private String status;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getAllocationDAte() {
		return allocationDAte;
	}
	public void setAllocationDAte(String allocationDAte) {
		this.allocationDAte = allocationDAte;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	@Override
	public String toString() {
		return "AssetAlllocationBean [allocationId=" + allocationId + ", assetId=" + assetId + ", empNo=" + empNo
				+ ", allocationDAte=" + allocationDAte + ", releaseDate=" + releaseDate + ", status=" + status + "]";
	}
	public AssetAllocationBean(int allocationId, int assetId, int empNo, String allocationDAte, String releaseDate,
			String status) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDAte = allocationDAte;
		this.releaseDate = releaseDate;
		this.status = status;
	}
	
	

}
