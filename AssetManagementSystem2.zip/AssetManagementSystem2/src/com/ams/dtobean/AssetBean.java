package com.ams.dtobean;

public class AssetBean {
	private String userType;
	private int assetId;
	private String assetName;
	private String assetDes;
	private int quantity;
	private String status;
	private int allocationId;
	private int empNo;
	private String allocationDate;
	private String releaseDate;
	
	
	public AssetBean(String assetName, String assetDes, int quantity, String status) {
		super();
		this.assetName = assetName;
		this.assetDes = assetDes;
		this.quantity = quantity;
		this.status = status;
	}



	private String username;
	private String password;
	
	
	public AssetBean(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetDes() {
		return assetDes;
	}
	public void setAssetDes(String assetDes) {
		this.assetDes = assetDes;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getAllocationDate() {
		return allocationDate;
	}
	public void setAllocationDate(String allocationDate) {
		this.allocationDate = allocationDate;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	
	
	public AssetBean() {
		super();
		
	}
	
	
	
	public AssetBean(String userType) {
		super();
		this.userType = userType;
	}
	public AssetBean(int assetId, String assetName, String assetDes, int quantity, String status, int allocationId,
			int empNo, String allocationDate, String releaseDate) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetDes = assetDes;
		this.quantity = quantity;
		this.status = status;
		this.allocationId = allocationId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}
	
	
	
	public AssetBean(String assetName, String assetDes, int quantity, String status, int allocationId, int empNo,
			String allocationDate, String releaseDate) {
		super();
		this.assetName = assetName;
		this.assetDes = assetDes;
		this.quantity = quantity;
		this.status = status;
		this.allocationId = allocationId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}
	
	
	
	@Override
	public String toString() {
		return "AssetBean [assetId=" + assetId + ", assetName=" + assetName + ", assetDes=" + assetDes + ", quantity="
				+ quantity + ", status=" + status + ", allocationId=" + allocationId + ", empNo=" + empNo
				+ ", allocationDate=" + allocationDate + ", releaseDate=" + releaseDate + "]";
	}
	
	
	
	 
	
}
