package com.ams.service;

import java.util.List;
import java.util.Scanner;

import com.ams.dao.AssetDaoImpl;
import com.ams.dao.IAsserDao;
import com.ams.dtobean.AssetAllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;

public class AssetService implements IAssetService
{
	IAsserDao idao=null;
	static Scanner scan=new Scanner(System.in);
	@Override
	public boolean validateuserType() throws AssetException
	{
			String un;
			String pass;
			AssetBean bean=null;
			try {
				idao=new AssetDaoImpl();
			do {
					System.out.println("enter username");
					un=scan.next();								
			        bean=idao.validateUserType(un);	 
			        if(bean==null)
			        	System.out.println("This username doesnot exists");
			   } while(bean==null); 
			do {
				   System.out.println("enter password");
				   pass=scan.next();	
				   if(!((bean.getUsername().equals(un))&&(bean.getPassword().equals(pass))))
				   {
					   System.out.println("Password is incorrect");
				   }
			   }while(!((bean.getUsername().equals(un))&&(bean.getPassword().equals(pass))));
			}catch(AssetException ae)
			{
				System.out.println("invalid"+ae.getMessage());
			}
			return true; 
	}
	@Override
	public int insertAsset(AssetBean bean2) {
		idao=new AssetDaoImpl();
		return idao.insertAsset(bean2);
	}
	@Override
	public int updateAsset(int id,int quantities,String name) throws AssetException {
		idao=new AssetDaoImpl();
		
		return idao.updateAsset(id,quantities,name);
	}
	@Override
	public int raiseRequest(AssetAllocationBean allocBean) throws AssetException {
		idao=new AssetDaoImpl();
		return idao.raiseRequest(allocBean);
	}
	@Override
	public int validateAssetId() throws AssetException {
		idao=new AssetDaoImpl();
		int assetId=0;
		System.out.println("Enter AssetId to be allocated");
		assetId=scan.nextInt();
		idao.validateAssetId(assetId);
		return 0;
	}
	@Override
	public int updateAssetStatus(int allocationId,String stat) {
		idao=new AssetDaoImpl();
		return idao.updateAssetStatus(allocationId,stat);
	}
	@Override
	public List<AssetAllocationBean> retrieveAll() {
		idao=new AssetDaoImpl();
		return idao.retrieveAll();
	}

}
