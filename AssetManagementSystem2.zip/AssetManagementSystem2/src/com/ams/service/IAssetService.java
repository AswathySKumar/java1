package com.ams.service;

import java.util.List;

import com.ams.dtobean.AssetAllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;

public interface IAssetService {

	public abstract boolean validateuserType() throws AssetException;

	public abstract int insertAsset(AssetBean bean2);

	public abstract int updateAsset(int id,int quantities, String name) throws AssetException;

	public abstract int raiseRequest(AssetAllocationBean allocBean) throws AssetException;
 
	public abstract int validateAssetId() throws AssetException;

	public abstract int updateAssetStatus(int allocationId, String stat);

	public abstract List<AssetAllocationBean> retrieveAll();
}
