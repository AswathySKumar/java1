package com.ams.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.ams.dao.AssetDaoImpl;
import com.ams.dtobean.AssetBean;
import com.ams.exception.AssetException;


public class TestCase {






}