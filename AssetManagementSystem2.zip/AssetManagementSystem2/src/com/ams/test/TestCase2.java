package com.ams.test;

import java.sql.Connection;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ams.dao.AssetDaoImpl;
import com.ams.dtobean.AssetBean;
import com.ams.exception.AssetException;
import com.ams.util.DbUtil;

public class TestCase2 {


}
