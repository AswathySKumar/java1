package com.ams.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ams.dao.IQueryMapper;
import com.ams.dtobean.AssetAllocationBean;
import com.ams.dtobean.AssetBean;
import com.ams.dtobean.EmployeeBean;
import com.ams.exception.AssetException;
import com.ams.service.AssetService;
import com.ams.service.IAssetService;
import com.ams.util.DbUtil;


public class AssetClient {
	static Scanner scan=null;
	static IAssetService serv=null;
	static AssetBean bean=null;
	static Logger logg=Logger.getRootLogger();
	public static void main(String[] args) throws AssetException, SQLException {
		PropertyConfigurator.configure("resource/log4j.properties");
		System.out.println("===Asset management system===");
		System.out.println("--------------------------------");
		Scanner scan=new Scanner(System.in);
		int type=0;
		do {
			System.out.println("select usertype \n"+"1.Manager \n"+"2. Admin");
			type=scan.nextInt();
			if(type<1||type>2)
				System.out.println("Enter valid user type");
			}while(type<1||type>2);
			
		
		serv = new AssetService();
		
		boolean valid=serv.validateuserType();	
		
		int assetid;
		String assetName;
		String assetDesc;
		int quantity;
		String status;
		  switch(type) {
		  case 1: System.out.println("Enter the choice \n"+"1. Raise a request \n"+"2. View status of Raised requests");
		          int choice1=scan.nextInt();
		          switch(choice1) {
		          case 1: System.out.println("Enter the details");
		                  
		          
		          
		          break;
		          
		          
		          
		          
		          
		          
		          
		          
		          }break;
		        
		  case 2:
		         System.out.println("Enter the choice\n 1.INSERT\n 2.UPDATE \n 3.VIEW AND UPDATE STATUS");
		         int choice=scan.nextInt();
		         int staus=0;
		         switch(choice)
		         {
		          case 1:System.out.println("****************************");
		        	     System.out.println("INSERT THE ASSET DETAILS");
		        	     System.out.println("****************************");
		        	     
			             System.out.println("Enter the asset name ");
			             assetName=scan.next();
			             
			             System.out.println("enter the asset description");
			             assetDesc=scan.next();
			             
			             System.out.println("Enter the quatity");
			             quantity=scan.nextInt();
			             
			             System.out.println("Enter the status");
			             status=scan.next();
			             
			             bean=new AssetBean(assetName,assetDesc,quantity,status);
		
		                 int add=insertAsset(bean);
		                 if(add>0)
		                 {
			                System.out.println("INSERTED");
		                 }
		                else
		                 {
			                System.out.println("NOT INSERTED");
		                 } 
		                 break;
		                 
		         case 2:int status1=0;
		         		System.out.println("************************");
		        	    System.out.println("UPDATE ASSET DETAILS");
		        	    System.out.println("************************");   
			            System.out.println("Enter asset id");
			            int id = scan.nextInt();
			            System.out.println("Enter name to be updated");
			            String name=scan.next();
			            System.out.println("Enter the quantity");
			            int quantities=scan.nextInt();
			            try{
					    	    status1=updateAsset(id,quantities,name);
					    	  
					    	    if(status1>0)
					    	    {
					    	    	 System.out.println(status1+"data is updated");
							    }
							    else
							    {
							    	    System.out.println("data is not updated");
							    }
			            	}
			            	catch(AssetException re)
			            	{
			            		System.out.println(re.getMessage());			    	   
			            	}
			           break;
		         case 3:List<AssetAllocationBean> assetList=null;
		         		assetList=retreiveAllAssetInfo();
		         		for(AssetAllocationBean asset:assetList)
		         		{
		         			System.out.println(asset);
		         		}
		        	 
		        	 
		        	 
		        	 	int status2=0;
		         		System.out.println("************************");
		         		System.out.println("UPDATE STATUS OF ASSET");
		         		System.out.println("************************");
		         		System.out.println("Enter the allocation id to update status");
		         		int allocationId=scan.nextInt();
		         		System.out.println("Enter the status for allocation");
		         		String stat=scan.next();
		         		
		         		status1=updateAssetStatus(allocationId,stat);
		         		if(status2==0)
		         		{
		         			System.out.println("STATUS UPDATED");
		         		}
		         		else
		         		{
		         			System.out.println("STATUS NOT UPDATED");
		         		}
		         
		         		break;
		         case 4:System.exit(0);
			           default:System.out.println("Invalid choice!!");
			           break;
		
		          }
		  }
        
		}
	private static List<AssetAllocationBean> retreiveAllAssetInfo() {
		serv=new AssetService(); 
		return serv.retrieveAll();
	}
	private static int updateAssetStatus(int allocationId, String stat) {
		
		return serv.updateAssetStatus(allocationId,stat);
	}
	public static int raiseRequest(AssetAllocationBean allocBean) throws AssetException {
		
		serv=new AssetService();
		return serv.raiseRequest(allocBean);
		
		}
		public static AssetBean viewStatusOfRaisedRequest() {
			
			return null;
		}
	public static int insertAsset(AssetBean bean2) {
		serv= new AssetService();
		return serv.insertAsset(bean2);
	}
	public static int updateAsset(int id,int quantities, String name) throws AssetException {
		serv= new AssetService();
		
		return serv.updateAsset(id,quantities,name);
	}
	
}