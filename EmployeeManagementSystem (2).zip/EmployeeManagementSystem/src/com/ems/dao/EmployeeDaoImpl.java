package com.ems.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.ems.dtobean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.util.DbUtil;


public class EmployeeDaoImpl implements IEmployeeDao
{
	Connection conn=null;
	@Override
	public int storeEmployee(EmployeeBean employee) throws EmployeeException{
		//db code
		//jdbc codes
		int status=0;
		conn=DbUtil.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement("insert into employee1 values(employee_seq.NEXTVAL,?,?,?,?)");
			pst.setString(1,employee.getEmpName());
			pst.setString(3, employee.getEmpmobile());
			pst.setInt(4,employee.getSal());
			pst.setString(2,employee.getEmpEmail());
			status=pst.executeUpdate();
			System.out.println("successfull");
		} catch (SQLException e) {
			throw new EmployeeException("data not stored "+e.getMessage());
		}
		
		return status;
	}

	@Override
	public List<EmployeeBean> getAllEmployees() throws EmployeeException {
		conn=DbUtil.getDbConnection();
		List<EmployeeBean> empList=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.SELECT_EMPLOYEE_QRY);
			empList=new ArrayList();
			EmployeeBean emp=null;
			while(rs.next()){
				emp=new EmployeeBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
				empList.add(emp);
			}
			
			
		} catch (SQLException e) {
			//catch it as predefined and throw it as user defined with message
			//raise excpetion
			throw new EmployeeException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return empList;
	}

}
