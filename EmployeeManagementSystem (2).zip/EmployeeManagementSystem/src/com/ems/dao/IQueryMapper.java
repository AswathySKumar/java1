package com.ems.dao;

public interface IQueryMapper {
	public static final String EMPLOYEE_INSERT_QRY="insert into employee1 values(employee_seq.NEXTVAL,?,?,?,?)";
	public static final String SELECT_EMPLOYEE_QRY="SELECT * FROM Employee1";
	

}
