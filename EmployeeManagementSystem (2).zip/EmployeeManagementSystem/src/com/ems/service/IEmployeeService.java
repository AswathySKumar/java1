package com.ems.service;
import java.util.List;

import com.ems.dtobean.EmployeeBean;
import com.ems.exception.EmployeeException;


public interface IEmployeeService {
	public abstract int storeEmployee(EmployeeBean employee)throws EmployeeException;
	public abstract List<EmployeeBean> getAllEmployees()throws EmployeeException;
	
}
