package com.hbs.dao;

import com.hbs.exception.HotelException;
import com.hds.bean.UserBean;

public interface IHotelDao {

	public abstract int register(UserBean ub) throws HotelException;
	public abstract boolean login(String user_id, String password) throws HotelException;
	public abstract void availrooms();
	public abstract void bookingstatus();


}
