package com.hbs.dao;

public interface IQueryMapper {
	public static final String HOTEL_REGISTER_QRY="INSERT INtO users VALUES(?,?,?,?,?,?,?,?)";
	public static final String Login_QRY="select * from users where user_id=? and password=?";
}
