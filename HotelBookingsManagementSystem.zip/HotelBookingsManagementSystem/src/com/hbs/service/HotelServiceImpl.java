package com.hbs.service;

import com.hbs.dao.HotelDaoImpl;
import com.hbs.dao.IHotelDao;
import com.hbs.exception.HotelException;
import com.hds.bean.UserBean;

public class HotelServiceImpl implements IHotelService{
	IHotelDao dao=new HotelDaoImpl();

	@Override
	public int register(UserBean ub) throws HotelException {
		return dao.register(ub);
		
	}

	@Override
	public boolean login(String user_id, String password) throws HotelException {
		boolean status=dao.login(user_id, password);
		return status;
	}

	@Override
	public void availrooms() {
		dao.availrooms();
		
	}

	@Override
	public void bookingstatus() {
		dao.bookingstatus();
		
	}

}
