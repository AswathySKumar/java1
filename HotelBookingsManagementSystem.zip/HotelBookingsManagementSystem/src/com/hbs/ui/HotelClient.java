package com.hbs.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.hbs.exception.HotelException;
import com.hbs.service.HotelServiceImpl;
import com.hbs.service.IHotelService;
import com.hds.bean.UserBean;




public class HotelClient {
static Scanner scan=null;
static UserBean ub=null;
static IHotelService serv=new HotelServiceImpl();
Connection conn=null;

	
	
	
public static void main(String[] args) throws HotelException {
	System.out.println("===WELCOME TO TREEBO===");
	System.out.println("--------------------------------");
	System.out.println("1. Register/login");
	System.out.println("2. Book Hotels");
	System.out.println("3. view Booking status");
	System.out.println("4.Exit");
	System.out.println("--------------------------------");
	scan=new Scanner(System.in);
	int option=scan.nextInt();
	switch(option){
	
	case 1:
		System.out.println("1.login/2.register");
		int op=scan.nextInt();
	switch(op) {
	case 1:
		login();
		break;
	case 2:
		register();
		break;
	default:
		System.out.println("Option not found. please try again...");
		
	}
	case 2:
		System.out.println(" Rooms available are :");
		serv.availrooms();
		break;
		
case 3:
		System.out.println("Please Login to continue...");
		login();
		break;
case 4:
		System.exit(0); break;
	
}
}



private static void register() throws HotelException {
	int status = 0;
	System.out.println("please enter your id ");
	String user_id=scan.next();
	System.out.println("please enter your password ");
	 String password=scan.next();

		System.out.println("please enter your role");
		String role = scan.next();
		System.out.println("please enter your username");
		 String username = scan.next();

			System.out.println("please enter your mobilenumber ");
			String mblnum = scan.next();
			System.out.println("please enter your phone ");
			 String ph = scan.next();

				System.out.println("please enter your address ");
				String add = scan.next();
				System.out.println("please enter your email ");
				 String email = scan.next();
			
				ub=new UserBean(email, email, role, username, mblnum, ph, add, email);
				try {
				 status= serv.register(ub);
				} 
				catch(HotelException e) {
					System.out.println(e.getMessage());
				}
				if(status>0) {
					System.out.println("registration successfull");
					login();
				}
				else {
					System.out.println("try again");
				}
			
	
}



private static void login() throws HotelException {
	System.out.println("please enter your id ");
	String user_id=scan.next();
	System.out.println("please enter your password ");
	String  password=scan.next();
	boolean status=serv.login(user_id,password);
	if(status==true){
	
		System.out.println(" 1. Check room Availability\n 2. Check Booking Status ");	
		int option1=scan.nextInt();
		switch (option1) {
		case 1: 
			serv.availrooms();
			
			break;
			
		case 2: 
			serv.bookingstatus();
			
			break;

		default:
			break;
		}
		
		
	}
	else{
		System.out.println(" Credentials not found, Please enter correct details or register again ");
	}
	 
	
}
}