package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.entity.Author;

public class AuthorDaoImpl implements IAuthorDao {
	private EntityManager entityManager;
	

	public AuthorDaoImpl() {
		entityManager=JpaUtil.getEntityManager();
	}

	@Override
	public void addAuthor(Author author) {
		entityManager.persist(author);
		
	}

	@Override
	public void updateAuthor(Author author) {
		entityManager.merge(author);
	}

	@Override
	public void removeAuthor(Author author) {
		entityManager.remove(author);
		
	}

	@Override
	public Author findAuthorById(int id) {
		Author ta=entityManager.find(Author.class, id);
		return ta;
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

}
