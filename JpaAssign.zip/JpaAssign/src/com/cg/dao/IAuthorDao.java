package com.cg.dao;

import com.cg.entity.Author;

public interface IAuthorDao {
	public abstract void addAuthor(Author author);
	public abstract void updateAuthor(Author author);
	public abstract void removeAuthor(Author author);
	public abstract Author findAuthorById(int id);
	public abstract void beginTransaction() ;
	public abstract void commitTransaction();


}
