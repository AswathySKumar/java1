package com.cg.service;

import com.cg.dao.AuthorDaoImpl;
import com.cg.dao.IAuthorDao;

import com.cg.entity.Author;

public class AuthorServiceImpl implements IAuthorService{
	IAuthorDao dao=new AuthorDaoImpl();
	

	@Override
	public void addAuthor(Author author) {
		dao.beginTransaction();
		dao.addAuthor(author);
		dao.commitTransaction();
		
	}

	@Override
	public void updateAuthor(Author author) {
		dao.beginTransaction();
	dao.updateAuthor(author);
	dao.commitTransaction();
		
	}

	@Override
	public void removeAuthor(Author author) {
		dao.beginTransaction();
		dao.removeAuthor(author);
		dao.commitTransaction();
		
	}

	@Override
	public Author findAuthorById(int id) {
		dao.findAuthorById(id);
		return dao.findAuthorById(id);
	}

}
