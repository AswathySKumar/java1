package com.cg.ui;

import com.cg.entity.Author;
import com.cg.service.AuthorServiceImpl;

public class Authors {
	public static void main(String[] args) {
		AuthorServiceImpl serv=new AuthorServiceImpl();
		Author a=new Author();
		a.setAuthorId(1001);
		a.setFirstName("aswathy");
		a.setMiddleName("s");
		a.setLastName("kumar");
		a.setPhoneNo(8547);
		serv.addAuthor(a);
		
	/*	a=serv.findAuthorById(1001);
		System.out.println("Name:"+a.getFirstName());
		System.out.println("middle:"+a.getMiddleName());
		System.out.println("lastname:"+a.getLastName());
		System.out.println("phoneno:"+a.getPhoneNo());
		
		a=serv.findAuthorById(1001);
		a.setPhoneNo(9446);
		serv.updateAuthor(a);
		System.out.println("id:"+a.getAuthorId());
		System.out.println("Name:"+a.getFirstName());
		System.out.println("middle:"+a.getMiddleName());
		System.out.println("lastname:"+a.getLastName());
		System.out.println("phoneno:"+a.getPhoneNo());
		
		a=serv.findAuthorById(1001);
		serv.removeAuthor(a);
		*/
		
	}

}
