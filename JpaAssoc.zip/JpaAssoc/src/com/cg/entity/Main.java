package com.cg.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
public static void main(String[] args) {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager=factory.createEntityManager();
	entityManager.getTransaction().begin();
	
	Student s=new Student();
	s.setName("aswathy");
	Address a=new Address();
	
	a.setStreet("siruseri");
	a.setCity("chennai");
	a.setState("TamilNadu");
	a.setZipcode("685602");
	s.setAddress(a);
	entityManager.persist(s);
	entityManager.getTransaction().commit();
	entityManager.close();
	factory.close();
	
}
}
