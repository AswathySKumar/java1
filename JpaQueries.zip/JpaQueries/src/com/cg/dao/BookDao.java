package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entity.Book;

public class BookDao implements BookDaoImpl{
	 EntityManager entityManager;

	public BookDao() {
		entityManager=DbUtil.getEntityManager();	
	}

	@Override
	public Book getBookById(int id) {
		Book book=entityManager.find(Book.class,id);
		return book;
	}

	@Override
	public List<Book> getBookByTitle(String title) {
		String qStr="SELECT book FROM Book book WHERE book.title LIKE :ptitle";
		TypedQuery<Book> query=entityManager.createQuery(qStr,Book.class);
		
		query.setParameter("ptitle","%"+title+"%");
		
		return query.getResultList();
	}

	@Override
	public Long getBookCount() {
		String s="SELECT count(book.id) FROM Book book";
		TypedQuery<Long> query=entityManager.createQuery(s,Long.class);
		Long boo=query.getSingleResult();
		return boo;
	}

	@Override
	public List<Book> getAuthorBooks(String author) {
		String q="SELECT book FROM Book book WHERE book.author=:pname";
		TypedQuery<Book> query=entityManager.createQuery(q,Book.class);
		query.setParameter("pname",author);
		return query.getResultList();
	}

	@Override
	public List<Book> getAllBooks() {
		Query query=entityManager.createNamedQuery("getAllBooks");
		List<Book> booklist=query.getResultList();
		return booklist;
	}

	@Override
	public List<Book> getBooksInPriceRange(double low, double high) {
		String qStr="SELECT book FROM Book book WHERE book.price BETWEEN :low and :high";
		TypedQuery<Book> query=entityManager.createQuery(qStr,Book.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		return query.getResultList(); 
	}

}
