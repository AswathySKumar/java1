package com.cg.ui;

import com.cg.entity.Book;
import com.cg.service.BookService;
import com.cg.service.BookServiceImpl;

public class Books {
public static void main(String[] args) {
	BookService ne=new BookServiceImpl();
	
	System.out.println("*******Listing total number of books********");
	System.out.println("Total books:"+ne.getBookCount());
	System.out.println("**********Listing book with id 105**********");
	System.out.println("Book with ID 105:"+ne.getBookById(105));
	System.out.println("*******Listing all Books**************");
	for(Book book:ne.getAllBooks()) {
	System.out.println(book);
	}
	System.out.println("*************Listing book an Android***********");
	for(Book book:ne.getBookByTitle("Android")) {
		System.out.println(book);
	}
	System.out.println("******Books by author*********");
	System.out.println("Book by author"+ne.getAuthorBooks("Danny Coward"));
	System.out.println("*****books in range***********");
	System.out.println("books in range:"+ne.getBooksInPriceRange(300, 500));
}
}
