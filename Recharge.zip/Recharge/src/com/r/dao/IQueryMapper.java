package com.r.dao;

public interface IQueryMapper {
	public static final String Recharge_INSERT_QRY="insert into recharge values(recharge_seq.NEXTVAL,?,?,?,?,?)";
	public static final String SELECT_Recharge_QRY="SELECT * FROM Recharge";
	
}
