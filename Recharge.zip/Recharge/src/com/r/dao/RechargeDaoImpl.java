package com.r.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.r.dtobean.RechargeBean;
import com.r.exception.RechargeException;
import com.r.util.DBUtil;

public class RechargeDaoImpl implements IRechargeDao
{
	Connection conn=null;
	@Override
	public int storeRecharge(RechargeBean recharge) throws RechargeException{
		//db code
		//jdbc codes
		int status=0;
		conn=DBUtil.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.Recharge_INSERT_QRY);
			pst.setString(1,recharge.getCustName());
			pst.setString(2,recharge.getMobileNo());
			pst.setInt(3,recharge.getRechAmount());
			pst.setInt(4,recharge.getRechPlan());
			pst.setString(5,recharge.getDate());
			status=pst.executeUpdate();
			System.out.println("successfull");
		} catch (SQLException e) {
			throw new RechargeException("data not stored "+e.getMessage());
		}
		
		return status;
	}

/*	@Override
	public List<RechargeBean> getAllRecharge() throws RechargeException {
		conn=DBUtil.getDbConnection();
		ArrayList empList=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.SELECT_Recharge_QRY);
			empList=new ArrayList();
			RechargeBean emp=null;
			while(rs.next()){
				emp=new RechargeBean(rs.getString(2),rs.getString(1),rs.getInt(3),rs.getString(5),rs.getString(4));
				empList.add(emp);
			}
			
			
		} catch (SQLException e) {
			//catch it as predefined and throw it as user defined with message
			//raise excpetion
			throw new RechargeException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return empList;
	}
*/
	@Override
	public List<RechargeBean> getAllRecharge() throws RechargeException {
		conn=DBUtil.getDbConnection();
		ArrayList empList=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.SELECT_Recharge_QRY);
			empList=new ArrayList();
			RechargeBean emp=null;
			while(rs.next()){
				emp=new RechargeBean(rs.getString(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5));
				empList.add(emp);
			}
			
			
		} catch (SQLException e) {
			//catch it as predefined and throw it as user defined with message
			//raise excpetion
			throw new RechargeException("couldn't retrieve data from db  "+e.getMessage());
		}
		
		return empList;
	}

}
