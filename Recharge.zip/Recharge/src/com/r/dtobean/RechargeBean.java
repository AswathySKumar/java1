package com.r.dtobean;

public class RechargeBean {
	private int custId;
	private String custName;
	private String mobileNo;
	private int rechAmount;
	private int rechPlan;
	private String date;
	
	
	
	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getMobileNo() {
		return mobileNo;
	}



	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}



	public int getRechAmount() {
		return rechAmount;
	}



	public void setRechAmount(int rechAmount) {
		this.rechAmount = rechAmount;
	}



	public int getRechPlan() {
		return rechPlan;
	}



	public void setRechPlan(int rechPlan) {
		this.rechPlan = rechPlan;
	}



	public String getDate() {
		return date;
	}



	public void setDate(String date) {
		this.date = date;
	}



	



	public RechargeBean(String custName, String mobileNo, int rechAmount, int rcplan, String date) {
		super();
		this.custName = custName;
		this.mobileNo = mobileNo;
		this.rechAmount = rechAmount;
		this.rechPlan = rcplan;
		this.date = date;
	}



	public RechargeBean(int custId, String custName, String mobileNo, int rechAmount, int rechPlan, String date) {
		//super();
		this.custId = custId;
		this.custName = custName;
		this.mobileNo = mobileNo;
		this.rechAmount = rechAmount;
		this.rechPlan = rechPlan;
		this.date = date;
	}



	



	@Override
	public String toString() {
		return "RechargeBean [custId=" + custId + ", custName=" + custName + ", mobileNo=" + mobileNo + ", rechAmount="
				+ rechAmount + ", rechPlan=" + rechPlan + ", date=" + date + "]";
	}



	


}
