package com.r.service;

import java.util.List;

import com.r.dtobean.RechargeBean;
import com.r.exception.RechargeException;


public interface IRechargeService {
	public abstract int storeRecharge(RechargeBean recharge)throws RechargeException;
	public abstract List<RechargeBean> getAllRecharge()throws RechargeException;
	
}
