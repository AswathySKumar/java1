package com.r.service;

import java.util.List;

import com.r.dao.IRechargeDao;
import com.r.dao.RechargeDaoImpl;
import com.r.dtobean.RechargeBean;
import com.r.exception.RechargeException;


public class RechargeService implements IRechargeService
{
	IRechargeDao edao=null;
	
	@Override
	public int storeRecharge(RechargeBean recharge) throws RechargeException {
		edao=new RechargeDaoImpl();
		int retId=edao.storeRecharge(recharge);
		return retId;
	}

	@Override
	public List<RechargeBean> getAllRecharge() throws RechargeException {
		edao=new RechargeDaoImpl();
		
		return edao.getAllRecharge();
	}



}
