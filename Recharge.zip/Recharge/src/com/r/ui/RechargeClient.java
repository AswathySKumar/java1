package com.r.ui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Scanner;

import com.r.dtobean.RechargeBean;
import com.r.exception.RechargeException;
import com.r.service.IRechargeService;
import com.r.service.RechargeService;



public class RechargeClient {
	static Connection conn=null;
	static Scanner scan=null;
	static int rcplan;
	static IRechargeService empServ=null;
	
	public static void main(String[] args) {
		System.out.println("===RECHARGE APPLICATION===");
		System.out.println("--------------------------------");
		System.out.println("1. RECHARGE NUMBER");
		System.out.println("2. retrieve All recharges ");
		System.out.println("3. UPDATE NAME");
		System.out.println("4.EXIT");
		System.out.println("--------------------------------");
		
		scan=new Scanner(System.in);
		int option=scan.nextInt();
		switch(option){
		
		case 1:
			//get user info
			System.out.println("enter ur name");
			String name=scan.next();
			System.out.println("enter ur mobile number");
			String mobile=scan.next();
			System.out.println("enter ur recharge amount");
			int rcamount=scan.nextInt();
			System.out.println("enter recharge plan..\n 1.RC 100\n 2.RC 200\n 3.RC 300");
			int rcplan1=scan.nextInt();
			switch(rcplan1){
				case 1:
					rcplan=100;
					break;
				case 2:
					rcplan=200;
					break;
				case 3:
					rcplan=300;
					break;
			}
			
			
			
			System.out.println("enter date");
			String date=scan.next();
			
			//set it to bean obj
			RechargeBean emp=new RechargeBean(name, mobile, rcamount,rcplan,date);
			//	validation
			//if validation succesfull
			int res=0;
			try {
				res = addRechargeInfo(emp);
			} catch (RechargeException e) {
			
			System.out.println(e.getMessage());
			}
			
			if(res>0){
				System.out.println(res+" data is inserted");
			}
			else
			{
				System.out.println("data is not stored");
			}
			break;
			
			
		case 2:
			List<RechargeBean> finList=null;
			try {
				finList = retrieveAllRechargeInfo();
			} catch (RechargeException e) {
				
				System.out.println(e.getMessage());
			}
		/*	Iterator it=finList.iterator();
			while(it.hasNext()){
				System.out.println(it.next());
			}*/
			
			for(RechargeBean empl:finList)
			{
			System.out.println(empl);	
			}
			break;
		case 3:

			try {

			ResultSet rs=null;

			System.out.println("Enter your mobile number");

			String mob=scan.next();

			String dbmob="select mobile from recharge where mobile="+mob;


			PreparedStatement p1= conn.prepareStatement(dbmob);

			rs=p1.executeQuery();

			while (rs!=null){

			System.out.println("enter name to update");

			String newname=scan.next();

			String qry1="update recharge set name=? where mobile="+mob;

			PreparedStatement p= conn.prepareStatement(qry1);

			p.setString(1,newname);

			p.executeUpdate();

			System.out.println("updated");//}else {System.out.println("mobile number doesn't exist ");} */

			break;

			}}

			catch (Exception e) {



			System.out.println(" Cannot update : "+e.getMessage());

			}

			break;

			
		case 4:
			System.exit(0);
			
			break;
			
			default:
				
		
		
		
		}
		
	}
	
	public static int addRechargeInfo(RechargeBean emp) throws RechargeException{
		//delegate the call to method in service - also pass the data
		empServ=new RechargeService();
		int result=empServ.storeRecharge(emp);
		return result;
	}
	public static List<RechargeBean> retrieveAllRechargeInfo() throws RechargeException{
		empServ=new RechargeService();
		
		return empServ.getAllRecharge();
	}

}
