package com.cg.bean;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePropertySource;

public class Client {

	public static void main(String[] args) {
		Resource res=new ClassPathResource("currencyconverter.xml");
BeanFactory factory=new XmlBeanFactory(res);
CurrencyConverter curr=(CurrencyConverter)factory.getBean("currencyconverter");
double rupees=curr.dollortorupees(50.0);
System.out.println(rupees);
}
}