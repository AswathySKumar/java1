package com.cg.bean;

public class CurrencyConverterImpl implements CurrencyConverter {
	
private ExchangeService exchangeService;
	@Override
	public double dollortorupees(double doller) {
				
		return doller*exchangeService.ExchangeRate();
	}
	public ExchangeService getExchangeService() {
		return exchangeService;
	}
	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}

	
}
