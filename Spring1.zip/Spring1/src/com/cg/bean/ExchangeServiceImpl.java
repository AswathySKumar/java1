package com.cg.bean;

public class ExchangeServiceImpl implements ExchangeService
{
private double exchangeRate;
public double getExchangeRate() {
	return exchangeRate;
}
public void setExchangeRate(double exchangeRate) {
	this.exchangeRate = exchangeRate;
}
@Override
public double ExchangeRate() {
	
	return exchangeRate;
}
public ExchangeServiceImpl(double exchangeRate) {
	super();
	this.exchangeRate = exchangeRate;
}



}
