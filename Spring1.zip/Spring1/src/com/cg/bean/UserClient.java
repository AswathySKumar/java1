package com.cg.bean;

public class UserClient {
public static void main(String[] args) {
	
}
}
