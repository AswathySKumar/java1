package com.cg.bean;

import java.sql.Date;

public class Employee {
private Date date;

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}

}
