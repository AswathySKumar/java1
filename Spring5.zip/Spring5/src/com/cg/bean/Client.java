package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory=new ClassPathXmlApplicationContext("currencyconverter.xml");
		//Resource res=new ClassPathResource("currencyconverter.xml");
		//BeanFactory factory=new XmlBeanFactory(res);
CurrencyConverter curr=(CurrencyConverter)factory.getBean("currencyConverter");
double rupees=curr.dollortorupees(50.0);
System.out.println(rupees);
}
}