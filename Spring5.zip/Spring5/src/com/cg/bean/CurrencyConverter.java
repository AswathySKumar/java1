package com.cg.bean;

public interface CurrencyConverter {
public abstract double dollortorupees(double doller);
}
