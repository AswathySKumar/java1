package com.cg.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.security.auth.Destroyable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("currencyConverter")
public class CurrencyConverterImpl implements CurrencyConverter {
@Autowired
private ExchangeServiceImpl exchangeService;
	@Override
	public double dollortorupees(double doller) {
				
		return doller*exchangeService.ExchangeRate();
	}
	public ExchangeService getExchangeService() {
		return exchangeService;
	}
	@Autowired
	public void setExchangeService(ExchangeServiceImpl exchangeService) {
		this.exchangeService = exchangeService;
	}
@PostConstruct
	private void init() {
		System.out.println("init method");

	}
@PreDestroy
	public void destroy() {
		System.out.println("destroy method");
		
}
public CurrencyConverterImpl() {
	
	
}

}

