package com.cg.bean;

public interface ExchangeService {
	public  double ExchangeRate();

}
