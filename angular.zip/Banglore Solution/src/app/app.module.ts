import { NgModule }      from '@angular/core';//importing NgModule
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';//importing AppComponent
import { HttpModule } from '@angular/http';//importing HttpModule
import { CollegeComponent } from './app.collegecomponent';//importing the CollegeComponent

@NgModule({
  imports:      [ BrowserModule,HttpModule ],
  declarations: [ AppComponent, CollegeComponent ], //Declaring AppComponent, CollegeComponent
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
